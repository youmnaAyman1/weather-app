const apiKey = "538281cb5f0a6f03224f34cb3b3a4c59";
const APIURL = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=";
const searchInput = document.querySelector(".search input");
const searchButton = document.querySelector(".search button");
const temperature = document.querySelector(".temperature");
const cityName = document.querySelector(".city");
const humidity = document.querySelector(".humidity");
const wind = document.querySelector(".wind");
const weatherIcon = document.querySelector(".weatherIcon");

async function checkWeather(city) {
  try {
    const response = await fetch(APIURL + city + `&appid=${apiKey}`);

    if (!response.ok) {
      throw new Error('Failed to fetch weather data');
    }

    const data = await response.json();

    // Log the entire data object to inspect its structure
    console.log(data);

    // Check if necessary properties exist before accessing them
    if (data && data.main && data.main.temp && data.name && data.main.humidity && data.wind && data.wind.speed) {
      temperature.innerHTML = Math.round(data.main.temp) + "°C";
      cityName.innerHTML = data.name;
      humidity.innerHTML = data.main.humidity + "%";
      wind.innerHTML = data.wind.speed + "km/h";

      // Set weather icon based on the weather condition
      if (data.weather[0].main.toLowerCase() == "clouds") {
        weatherIcon.src = "images/clouds.png";
      } else if (data.weather[0].main.toLowerCase() == "clear") {
        weatherIcon.src = "images/clear.png";
      } else if (data.weather[0].main.toLowerCase() == "rain") {
        weatherIcon.src = "images/rain.png";
      } else if (data.weather[0].main.toLowerCase() == "drizzle") {
        weatherIcon.src = "images/drizzle.png";
      } else if (data.weather[0].main.toLowerCase() == "mist") {
        weatherIcon.src = "images/mist.png";
      }

      searchInput.value = "";
    } else {
      console.error('Incomplete or unexpected data structure in the API response');
    }
  } catch (error) {
    console.error('Error fetching or processing weather data:', error);
  }
  document.querySelector(".weatherDetails").style.display="block";
  document.querySelector(".detailsd").style.display="block";
}

searchButton.addEventListener("click", () => {
  checkWeather(searchInput.value);
});

searchInput.addEventListener("keydown", (e) => {
  if (e.key == "Enter") {
    checkWeather(searchInput.value);
  }
});
